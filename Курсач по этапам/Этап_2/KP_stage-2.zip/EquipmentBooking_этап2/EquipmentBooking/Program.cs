using EquipmentBooking.Data;
using EquipmentBooking.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Шаблон Razor Pages: каждая страница — файл .cshtml и класс модели страницы рядом
builder.Services.AddRazorPages();

builder.Services.AddDbContext<AppDbContext>(o => o.UseSqlite(builder.Configuration.GetConnectionString("Default")));

// Часы приложения. В тестах вместо системных подставляются «остановленные» часы
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddScoped<CatalogService>();
builder.Services.AddScoped<EmployeeService>();

var app = builder.Build();

// База создаётся и обновляется миграциями при запуске; при пустой базе добавляются учебные данные
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.Migrate();
    DbSeeder.Seed(db, TimeProvider.System.GetLocalNow().DateTime);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
// Неизвестный адрес → своя страница 404
app.UseStatusCodePagesWithReExecute("/NotFound");

app.UseStaticFiles();
app.UseRouting();
app.MapRazorPages();

// ---------- API для проверки HTTP-запросами (файл EquipmentBooking.http) ----------
var api = app.MapGroup("/api");

api.MapGet("/equipment", (string? search, CatalogService catalog) => catalog.Search(search));
api.MapGet("/equipment/{id:int}", (int id, CatalogService catalog) =>
    catalog.GetById(id) is { } item ? Results.Ok(item) : Results.NotFound(new { error = $"Оборудование с Id = {id} не найдено" }));

app.Run();

public partial class Program { }
