using EquipmentBooking.Models;
using EquipmentBooking.Services;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EquipmentBooking.Pages;

/// <summary>Главная: короткая сводка по каталогу и сотрудникам.</summary>
public class IndexModel : PageModel
{
    private readonly CatalogService _catalog;
    private readonly EmployeeService _employees;

    public IndexModel(CatalogService catalog, EmployeeService employees)
    {
        _catalog = catalog;
        _employees = employees;
    }

    public int Available { get; private set; }
    public int Maintenance { get; private set; }
    public int Total { get; private set; }
    public int EmployeeCount { get; private set; }

    public void OnGet()
    {
        var all = _catalog.Search(null);
        Available = all.Count(e => e.State == EquipmentState.Available);
        Maintenance = all.Count(e => e.State == EquipmentState.Maintenance);
        Total = all.Count;
        EmployeeCount = _employees.GetAll().Count;
    }
}
