# EquipmentBooking — модуль бронирования оборудования

Курсовой проект, тема №13: «Проектирование и разработка модуля бронирования оборудования».
ЧПОУ «Сургутский колледж предпринимательства», группа ИСиП-23/1, 2026.
ASP.NET Core Razor Pages, .NET 10, C#.

**Состояние: этап 3 — функции индивидуальной темы.**

## Что нужно установить
| Программа | Версия | Проверка |
|---|---|---|
| .NET SDK | 10.0 | `dotnet --version` → `10.x.x` |
| Браузер | любой | — |

Интернет нужен при первой сборке (пакеты NuGet) и для оформления страниц (Bootstrap с CDN).

## Запуск (PowerShell)
1. Распаковать архив в любую папку.
2. Открыть PowerShell в папке, где лежит `EquipmentBooking.sln`.
3. Выполнить:
```powershell
dotnet run --project EquipmentBooking
```
4. Открыть http://localhost:5090. Остановить — `Ctrl+C`.

В Visual Studio: открыть `EquipmentBooking.sln` и нажать F5.

## База данных и учебные данные
- Хранилище — SQLite через Entity Framework Core 10.0.15 (отдельно ставить SQLite не нужно).
- При запуске `Database.Migrate()` создаёт файл `EquipmentBooking/booking.db` и таблицы
  `Equipment`, `Employees`, `Bookings`, `BookingHistory` по миграции `Migrations/InitialCreate`.
- `Data/DbSeeder.cs` при пустой базе добавляет учебные данные: 11 единиц оборудования, 8 сотрудников, 14 броней
  (даты броней считаются от дня первого запуска).
- Данные сохраняются между запусками.
- **Восстановление учебной базы:** остановить приложение, удалить `EquipmentBooking/booking.db`, запустить снова.
- Другой способ: `dotnet tool install --global dotnet-ef`, затем `dotnet ef database update --project EquipmentBooking`.

Пакеты NuGet указаны в `EquipmentBooking.csproj`: `Microsoft.EntityFrameworkCore.Sqlite`, `Microsoft.EntityFrameworkCore.Design`.

## Сценарии демонстрации
**Успех.** «Свободно ли?» → завтра 10:00–12:00 → у документ-камеры «Забронировать на этот период» → бронь создана, статус «Активно».

**Отказ.** «Забронировать» → проектор INV-0001, завтра 11:00–13:00 → «уже забронировано с … 10:00 по … 12:00 (Громов А. Н.)». Бронь не создаётся.

## Адреса
| Адрес | Что показывает |
|---|---|
| `/Equipment` | каталог: поиск, фильтр по состоянию и категории |
| `/Availability` | «Свободно ли?» — доступность на период |
| `/Bookings/Create` | создание брони (проверка пересечений) |
| `/Bookings` | вкладки «Текущие» / «Завершённые и отменённые», фильтры |
| `/Bookings/Details/1` | карточка брони, отмена с причиной, журнал операций |
| `/Schedule` | график загрузки на неделю |
| `/Employees` | сотрудники |
| `/api/equipment`, `/api/availability`, `/api/bookings` | JSON |

## Структура (разделение слоёв)
```
Models/     Equipment, Employee, Booking, BookingHistory, перечисления
Data/       AppDbContext, DbSeeder; Migrations/
Services/   предметная логика: BookingService, BookingRules, CatalogService, EmployeeService
Forms/      формы и фильтры
Pages/      Razor Pages — обработка запросов, к базе напрямую не обращаются
```
История коммитов — `git-history.txt`.
